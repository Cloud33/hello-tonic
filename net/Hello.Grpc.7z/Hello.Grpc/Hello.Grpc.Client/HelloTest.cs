﻿using Grpc.Core;
using Grpc.Net.Client;
using Hello.Grpc.Server;


namespace Hello.Grpc.Client
{
    public class HelloTest
    {
        public async void GetHelloInfo()
        {
            string url = "http://localhost:50051";
            using (var channel = GrpcChannel.ForAddress(url))
            {
                var client = new Greeter.GreeterClient(channel);
                var request = client.SayHello(new HelloRequest
                {
                    Name = "Feng Lin"
                });
                System.Console.WriteLine(request.Message);
            }
            System.Console.ReadKey();
        }
    }
}
