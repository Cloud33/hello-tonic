﻿// See https://aka.ms/new-console-template for more information

using Hello.Grpc.Client;

try
{
    new HelloTest().GetHelloInfo();
}
catch (Exception ex)
{

	throw ex;
}
